import RPi.GPIO as GPIO
import time

class LCDContrastPWM:
    def __init__(self, pin, contrast_level=250, frequency=440):
        self.pin = pin
        self.contrast_level = min(max(int((contrast_level / 1023) * 100), 0), 100)
        self.frequency = frequency
        
        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.pin, GPIO.OUT)
        
        self.pwm = GPIO.PWM(self.pin, self.frequency)
        self.pwm.start(0)
        
    def set_contrast(self, level=None):
        if level is not None:
            self.contrast_level = min(max(int((level / 1023) * 100), 0), 100)
        self.pwm.ChangeDutyCycle(self.contrast_level)
        
    def cleanup(self):
        self.pwm.stop()
        GPIO.cleanup(self.pin)

if __name__ == "__main__":
    pwm_control = LCDContrastPWM(pin=12, contrast_level=1023)
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pwm_control.cleanup()