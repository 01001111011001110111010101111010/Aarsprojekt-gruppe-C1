from io import BytesIO
from flask import Flask, render_template, send_file, redirect, url_for, request, session
from matplotlib.figure import Figure
import paho.mqtt.publish as publish
import base64
import sqlite3
from functools import wraps
from get_ordre_data import get_ordre_dataen

app = Flask(__name__)
app.secret_key = 'yesyoucan'

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != 'fiskebarenadmin' or request.form['password'] != 'yesyoucan':
            error = 'Invalid Credentials. Please try again.'
        else:
            session['logged_in'] = True
            return redirect(url_for('home'))
    return render_template('login.html', error=error)

@app.route('/logout', methods=['GET', 'POST'])
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))

@app.route('/background-image')
@login_required
def background_image():
    return send_file('static/fisk2.jpg', mimetype='image/jpg')

@app.route('/')
@login_required
def home():
    return render_template('index.html')

@app.route('/ordreoverblik')
@login_required
def ordreoverblik():
    ordredata_graf = plot_ordre_data()
    return render_template('ordreoverblik.html', ordredata_graf=ordredata_graf)

@app.route('/tjenerstat')
@login_required
def tjenerstatistik():
    return render_template('tjenerstat.html')

@app.route('/enhed1')
@login_required
def enhed1():
    return render_template('enhed1.html')

@app.route('/enhed2')
@login_required
def enhed2():
    return render_template('enhed2.html')

@app.route('/drink1/', methods=['POST'])
@login_required
def drink1():
    publish.single("enhed1", "drink", hostname="20.13.148.230")
    return render_template('enhed1.html')

@app.route('/drink2/', methods=['POST'])
@login_required
def drink2():
    publish.single("enhed2", "drink", hostname="20.13.148.230")
    return render_template('enhed2.html')

@app.route('/mad1/', methods=['POST'])
@login_required
def mad1():
    publish.single("enhed1", "mad", hostname="20.13.148.230")
    return render_template('enhed1.html')

@app.route('/mad2/', methods=['POST'])
@login_required
def mad2():
    publish.single("enhed2", "mad", hostname="20.13.148.230")
    return render_template('enhed2.html')

@app.route('/resetknap/', methods=['POST'])
@login_required
def resetknap():
    conn = sqlite3.connect("database/ordredata.db")
    cur = conn.cursor()
    try:
        cur.execute("UPDATE ordre SET mad = 0, drink = 0")
        conn.commit()
    except sqlite3.Error as e:
        print(f"SQLite error occurred: {e}")
        conn.rollback()
    finally:
        conn.close()
    return redirect(url_for('ordreoverblik'))

def plot_ordre_data():
    mad_count, drink_count = get_ordre_dataen()
    fig = Figure()
    ax = fig.subplots()
    ax.set_xlabel('Ordre')
    ax.set_ylabel('Antal')
    ax.set_title('Antal af Mad- og Drinkordrer')

    if mad_count == 0 and drink_count == 0:
        buffer = BytesIO()
        fig.savefig(buffer, format='png')
        buffer.seek(0)
    else:
        labels = ['Mad', 'Drink']
        values = [mad_count, drink_count]
        ax.bar(labels, values, color=['green', 'red'])

    buf = BytesIO()
    fig.savefig(buf, format="png")
    data = base64.b64encode(buf.getbuffer()).decode("ascii")
    return data

if __name__ == '__main__':
    app.run(debug=True)
