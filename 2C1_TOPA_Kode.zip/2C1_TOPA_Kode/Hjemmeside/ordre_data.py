import sqlite3
import paho.mqtt.client as mqtt
import json

def create_table():
    query = """CREATE TABLE IF NOT EXISTS ordre (mad INTEGER DEFAULT 0, drink INTEGER DEFAULT 0);"""
    try:
        conn = sqlite3.connect("database/ordredata.db")
        cur = conn.cursor()
        cur.execute(query)
        cur.execute("INSERT INTO ordre (mad, drink) SELECT 0, 0 WHERE NOT EXISTS (SELECT 1 FROM ordre);")
        conn.commit()
    except sqlite3.Error as sql_e:
        print(f"SQLite error occurred: {sql_e}")
    except Exception as e:
        print(f"Error occurred: {e}")
    finally:
        if conn:
            conn.close()

create_table()

def on_message(client, userdata, message):
    query = """UPDATE ordre SET mad = mad + ?, drink = drink + ? WHERE rowid = 1"""
    json_data = json.loads(message.payload.decode())
    
    mad_count = 0
    drink_count = 0

    if json_data.get('ordre') == 'mad':
        mad_count = 1
    elif json_data.get('ordre') == 'drink':
        drink_count = 1

    data = (mad_count, drink_count)
    
    try:
        conn = sqlite3.connect("database/ordredata.db")
        cur = conn.cursor()
        cur.execute(query, data)
        conn.commit()
    except sqlite3.Error as sql_e:
        print(f"SQLite error occurred: {sql_e}")
        if conn:
            conn.rollback()
    except Exception as e:
        print(f"Error occurred: {e}")
    finally:
        if conn:
            conn.close()

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected successfully")
        client.subscribe("enhed1")
        client.subscribe("enhed2")
    else:
        print(f"Connect failed with code {rc}")

mqtt_client = mqtt.Client()
mqtt_client.on_connect = on_connect
mqtt_client.on_message = on_message

mqtt_client.connect("20.13.148.230", 1883, 60)

def publish_message(topic, message):
    mqtt_client.publish(topic, json.dumps(message))

mqtt_client.loop_start()