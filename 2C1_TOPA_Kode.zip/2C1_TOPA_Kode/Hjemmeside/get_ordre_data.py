import sqlite3
from datetime import datetime

def get_ordre_dataen():
    query = """SELECT mad, drink FROM ordre;"""
    mad_count = 0
    drink_count = 0
    
    try:
        conn = sqlite3.connect("database/ordredata.db")
        cur = conn.cursor()
        cur.execute(query)
        row = cur.fetchone()
        if row:
            mad_count, drink_count = row
        return mad_count, drink_count

    except sqlite3.Error as sql_e:
        print(f"sqlite error occured: {sql_e}")
    except Exception as e:
        print(f"Error occured: {e}")
    finally:
        conn.close()

mad_count, drink_count = get_ordre_dataen()
print(f"Madordrer: {mad_count}, Drinkordrer: {drink_count}")
