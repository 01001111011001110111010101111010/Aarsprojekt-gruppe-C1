import time
from machine import Pin, SPI, I2C, RTC, deepsleep
import ssd1306
import framebuf
from micropython_rfm9x import RFM9x
from adc_sub import ADC_substitute



def init_spi():
    RESET = Pin(14, Pin.OUT)
    CS = Pin(5, Pin.OUT)
    spi = SPI(2, baudrate=10000000, polarity=0, phase=0, bits=8, firstbit=SPI.MSB, sck=Pin(18), mosi=Pin(23), miso=Pin(19))
    return spi, CS, RESET

def init_lora(spi, CS, RESET):
    RADIO_FREQ_MHZ = 868.0
    return RFM9x(spi, CS, RESET, RADIO_FREQ_MHZ)

def init_i2c_oled():
    i2c = I2C(scl=Pin(21), sda=Pin(22))
    oled = ssd1306.SSD1306_I2C(128, 64, i2c)
    return i2c, oled

def init_leds():
    led_red = Pin(26, Pin.OUT)
    led_green = Pin(13, Pin.OUT)
    led_red.off()  
    led_green.off()  
    return led_red, led_green

def init_vibration_motor():
    return Pin(17, Pin.OUT)

def init_rotary_encoder():
    pin_a = Pin(25, Pin.IN)
    pin_b = Pin(27, Pin.IN)
    pin_sw = Pin(12, Pin.IN, Pin.PULL_UP)
    return pin_a, pin_b, pin_sw



def load_pbm(filename):
    with open(filename, 'rb') as f:
        f.readline()  
        f.readline()  
        f.readline()  
        data = bytearray(f.read())
    return framebuf.FrameBuffer(data, 128, 64, framebuf.MONO_HLSB)

def update_section_display(oled, section):  
    oled.fill(0)
    oled.text("Vaelg sektion", 0, 0)
    for i, sec in enumerate(sections):
        if i + 1 == section:
            oled.text("> " + sec, 0, 20 + i * 10)
        else:
            oled.text("  " + sec, 0, 20 + i * 10)
    oled.show()

def update_confirmation_display(oled, section):  
    oled.fill(0)
    oled.text("Sektion valgt:", 0, 0)
    oled.text(sections[section-1], 0, 20)
    oled.show()

def update_display(oled, number_images, value, elapsed_time, battery_pct):  
    oled.fill(0)
    if 0 <= value <= 99:
        tens = value // 10
        units = value % 10
        if tens > 0:
            oled.blit(number_images[tens], 0, 0)
        oled.blit(number_images[units], 45, 0)
    else:
        print("Ugyldigt tal:", value)
    
    
    oled.text(elapsed_time, 85, 54)
    
    
    oled.text(f'{battery_pct}%', 100, 0)  
    oled.show()

def display_battery_percentage(oled, battery_pct, elapsed_time):  
    oled.fill(0)  
    oled.text(f'{battery_pct}%', 100, 0)
    oled.text(elapsed_time, 85, 54)  
    oled.show()

def clear_screen(oled):
    oled.fill(0)
    oled.show()



def rotary_handler(pin):
    global counter, last_state_a, selected_section, section_chosen, in_section_mode
    current_state_a = pin_a.value()
    current_state_b = pin_b.value()

    if current_state_a != last_state_a:
        if current_state_a == 1:
            if current_state_b == 0:
                counter += 1
            else:
                counter -= 1

            if counter < 0:
                counter = 3
            elif counter > 3:
                counter = 0
            selected_section = counter + 1
            in_section_mode = True  
            clear_screen(oled)  
            update_section_display(oled, selected_section)

    last_state_a = current_state_a

def reset_counter(pin):
    global selected_section, battery_pct, section_chosen, in_section_mode
    print("Sektion valgt:", sections[selected_section - 1])
    section_chosen = True  
    in_section_mode = False  
    update_confirmation_display(oled, selected_section)
    time.sleep(2)  
    battery_pct = get_battery_percentage()  
    elapsed_time = "00:00"  
    display_battery_percentage(oled, battery_pct, elapsed_time)  



def receive_lora_data(rfm9x, vibration_motor, led_red, led_green):
    global last_received_time, last_received_value
    packet = rfm9x.receive(timeout=5.0)
    if packet is not None:
        try:
            received_str = str(packet, 'utf-8')
            print("Modtaget:", received_str)
            sender_id, value = received_str.split(',')
            sender_id = sender_id.strip()
            value = int(value.strip())

            if sender_id not in ["K1", "B1"]:
                print("Ugyldigt sender ID:", sender_id)
                return

            if not (1 <= value <= 99):
                print("Ugyldigt tal:", value)
                return

            if ((selected_section == 1 and 1 <= value <= 10) or
                (selected_section == 2 and 11 <= value <= 20) or
                (selected_section == 3 and 21 <= value <= 30) or
                (selected_section == 4 and 31 <= value <= 40)):

                if sender_id == "K1":
                    led_red.on()
                    led_green.off()
                elif sender_id == "B1":
                    led_red.off()
                    led_green.on()

                
                last_received_time = time.time()
                elapsed_time = "00:00"

                
                battery_pct = get_battery_percentage()
                last_received_value = value  

                update_display(oled, number_images, value, elapsed_time, battery_pct)  

                vibration_motor.on()
                time.sleep(1)
                vibration_motor.off()

        except ValueError:
            print("Kunne ikke dekode pakken: Ugyldigt format")
        except Exception as e:
            print("Kunne ikke dekode pakken:", e)



spi, CS, RESET = init_spi()
rfm9x = init_lora(spi, CS, RESET)
i2c, oled = init_i2c_oled()
led_red, led_green = init_leds()
vibration_motor = init_vibration_motor()
pin_a, pin_b, pin_sw = init_rotary_encoder()

counter = 0
selected_section = 1
sections = ['Sektion 1', 'Sektion 2', 'Sektion 3', 'Sektion 4']
last_state_a = pin_a.value()
section_chosen = False  
in_section_mode = True  
battery_pct = 0  
last_received_time = 0  
last_received_value = None  

number_images = [load_pbm('tal/' + str(i) + '.pbm') for i in range(10)]

update_section_display(oled, selected_section)

pin_a.irq(trigger=Pin.IRQ_RISING | Pin.IRQ_FALLING, handler=rotary_handler)
pin_sw.irq(trigger=Pin.IRQ_FALLING, handler=reset_counter)


rtc = RTC()  


pin_battery = 32
battery = ADC_substitute(pin_battery)  


ip1 = 1903
ip2 = 2756
bp1 = 0
bp2 = 100
alpha = (bp2 - bp1) / (ip2 - ip1)
beta = bp1 - alpha * ip1

def get_battery_percentage():  
    ip = battery.read_adc()
    bp = alpha * ip + beta
    bp = int(bp)
   
    if bp < 0:
        bp = 0
    elif bp > 100:
        bp = 100
    
    return bp

try:
    while True:
        if section_chosen and not in_section_mode:
            battery_pct = get_battery_percentage()  
            if last_received_time > 0:
                elapsed_seconds = int(time.time() - last_received_time)
                minutes = elapsed_seconds // 60
                seconds = elapsed_seconds % 60
                elapsed_time = "{:02}:{:02}".format(minutes, seconds)
            else:
                elapsed_time = "00:00"
            if last_received_value is not None:
                update_display(oled, number_images, last_received_value, elapsed_time, battery_pct)  
            else:
                display_battery_percentage(oled, battery_pct, elapsed_time)  
        if in_section_mode:
            update_section_display(oled, selected_section)  
        receive_lora_data(rfm9x, vibration_motor, led_red, led_green)
        time.sleep(1)
except KeyboardInterrupt:
    print("Program stoppet af bruger")
